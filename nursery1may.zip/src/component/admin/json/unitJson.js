const unitJson = {
  unitjson: ["gram", "kilogram", "piece", "miligram"],
};
export default unitJson;
