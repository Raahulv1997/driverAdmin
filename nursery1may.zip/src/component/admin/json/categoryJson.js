const CategoryJson = {
  categoryjson: ["Herbs", "Shrubs", "Trees", "Climbers", "Creepers", "plant"],
};
export default CategoryJson;
