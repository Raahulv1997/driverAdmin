const vendorJson = {
  vendorjson: [
    "rahul nursery",
    "mayur nursery",
    "ashish nursery ",
    "gourav wholesale plant",
    "shivani plant suppliers",
    "bhavna garden suppliers",
  ],
};
export default vendorJson;
