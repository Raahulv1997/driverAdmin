const brandJson = {
  brandjson: [
    "Natural Garden",
    "Bamboo Marigold",
    "Sneezewort Society",
    "Houseplant Hub",
    "Cactus Collective",
    " Blue Bamboo",
    "Crimson Creepers",
    " Wistful Wisteria",
    " Merry Botanics",
    " Bonsai & Bloom",
  ],
};
export default brandJson;
