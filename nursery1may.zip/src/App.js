import "./App.css";
import React from "react";

import Layout from "./layout";

function App() {
  return (
    <div>
      <Layout />
    </div>
  );
}

export default App;
